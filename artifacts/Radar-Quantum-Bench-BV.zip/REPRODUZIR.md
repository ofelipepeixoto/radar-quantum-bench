# Reproduzir o experimento Bernstein-Vazirani

Este pacote inclui as contagens, os circuitos OpenQASM e a revisão do programa
usada no ensaio. Os tempos registrados em `result.json` pertencem à máquina de
origem e variam com a carga e o equipamento.

No Linux x86_64 ou WSL2 x86_64 com Python 3.12, use uma cópia de confiança do Radar Quantum
Bench para conferir o ZIP antes de extraí-lo.

```bash
python3.12 -m radar_quantum_bench check-package caminho/para/pacote.zip
```

Os hashes permitem detectar inconsistências entre os arquivos. Para comprovar
a procedência, compare o SHA-256 do ZIP com um valor recebido por outro canal.

Extraia o pacote em uma pasta nova, abra o terminal nela e confira as métricas.

```bash
python3.12 -m radar_quantum_bench verify result.json
```

Para repetir as medições, instale as dependências fixadas e use a semente
registrada neste pacote.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m radar_quantum_bench run --circuit bv --seed 20261320 --output replay.json
python -m radar_quantum_bench verify replay.json
python -m unittest discover -s tests
```

Confira as contagens por condição, os parâmetros, o mapa de bits e as versões
do ambiente em ambos os arquivos. As comparações científicas devem usar os
dados por repetição e preservar as diferenças de ambiente observadas.
